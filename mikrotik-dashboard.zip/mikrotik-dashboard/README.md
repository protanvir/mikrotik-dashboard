# MikroTik CCR2116 Dashboard

Live monitoring dashboard for MikroTik CCR2116-12G-4S+ (RouterOS 7).

## Monitors
- CPU load & RAM usage (live sparklines)
- Temperature, fan speed, board voltage
- Per-interface RX/TX traffic (live bars)
- Active firewall connections (top 100)
- BGP session status & prefix counts

## Requirements
- Node.js 18+
- MikroTik running **RouterOS 7.x** (REST API required)
- Admin user on the router

## Setup

### 1. Enable REST API on MikroTik

Connect via Winbox or SSH and run:

```
# Enable www-ssl (recommended)
/ip service enable www-ssl
/ip service set www-ssl port=443

# Or plain HTTP (less secure)
/ip service enable www
```

If using HTTPS (default), the dashboard ignores the self-signed certificate automatically.

### 2. Install dependencies

```bash
cd mikrotik-dashboard
npm install
```

### 3. Configure

```bash
cp .env.example .env
nano .env   # or use any editor
```

Fill in:
```
ROUTER_IP=192.168.88.1          # Your router's IP
ROUTER_PORT=443                 # 443 for HTTPS, 80 for HTTP
ROUTER_USER=admin
ROUTER_PASS=your_password
MONITOR_INTERFACES=ether1,ether2,sfp-sfpplus1,sfp-sfpplus2
```

> **Tip:** Find interface names in Winbox → Interfaces, or via SSH:
> `/interface print`

### 4. Start

```bash
npm start
```

Open: **http://localhost:3000**

For auto-restart on changes during development:
```bash
npm run dev
```

## Run on startup (Linux)

Create a systemd service:

```bash
sudo nano /etc/systemd/system/mikrotik-dashboard.service
```

```ini
[Unit]
Description=MikroTik Dashboard
After=network.target

[Service]
WorkingDirectory=/path/to/mikrotik-dashboard
ExecStart=/usr/bin/node server.js
Restart=always
User=your-user
EnvironmentFile=/path/to/mikrotik-dashboard/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable mikrotik-dashboard
sudo systemctl start mikrotik-dashboard
```

## Troubleshooting

| Problem | Fix |
|---|---|
| "Cannot reach router" | Check ROUTER_IP and that www-ssl is enabled |
| Temperature shows N/A | Run `/system health print` on router to verify health sensor names |
| BGP shows empty | BGP may not be configured, or RouterOS path differs |
| Traffic shows — | Verify interface names match exactly (case-sensitive) |

## RouterOS REST API reference
- `GET /rest/system/resource` — CPU, RAM, uptime
- `GET /rest/system/health` — Temperature, fan, voltage
- `GET /rest/interface` — All interfaces
- `POST /rest/interface/monitor-traffic` — Live traffic
- `GET /rest/ip/firewall/connection` — Active connections
- `GET /rest/routing/bgp/session` — BGP sessions
